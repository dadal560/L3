# Arbres N-aires - TP Structures de Données

### Exécution des tests
```bash
cd /debug/ntree
make install
./test-ntree
```

