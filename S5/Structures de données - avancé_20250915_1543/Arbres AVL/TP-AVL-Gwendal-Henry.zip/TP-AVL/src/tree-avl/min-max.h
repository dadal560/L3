/*--------------------------------------------------------------------*/
#ifndef _MIN_MAX_H_
#define _MIN_MAX_H_

#ifndef MIN


#define MIN(x,y) ((x)>(y)?(y):(x))
#endif

#ifndef MAX
#define MAX(x,y) ((x)>(y)?(x):(y))
#endif

#endif

